package org.lastmilehealth.kiosk;

import android.app.Activity;

/**
 * Fake Activity - necessary to trigger "Select Home Launcher" screen.
 */
public class FakeLauncherActivity extends Activity {
}
