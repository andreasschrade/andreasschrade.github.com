package org.lastmilehealth.kiosk;
import android.app.Application;
import android.content.Intent;

/**
 * Created by Andreas Schrade on 17.09.2015.
 */
public class AppContext extends Application{

    private AppContext instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        startKioskService();
        Thread.setDefaultUncaughtExceptionHandler(new DefaultExceptionHandler(this));
    }

    private void startKioskService() { // ... and this method
        startService(new Intent(this, KioskService.class));
    }
}
