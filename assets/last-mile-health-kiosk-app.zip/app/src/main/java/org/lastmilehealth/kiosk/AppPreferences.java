package org.lastmilehealth.kiosk;

import android.content.Intent;
import android.os.Bundle;
import android.preference.Preference;
import android.widget.Toast;

import net.xpece.android.support.preference.AppCompatPreferenceActivity;

/**
 * Created by Andreas Schrade on 17.09.2015.
 */
public class AppPreferences extends AppCompatPreferenceActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        addPreferencesFromResource(R.xml.preferences);

        Preference exitButton = findPreference("pref_Exit");

        exitButton.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                PrefUtils.setKioskModeActive(false, getApplicationContext());
                KioskModeUtil.removeStatusbarOverlay(getApplicationContext());
                Toast.makeText(getApplicationContext(), "Please set the regular Home Screen as default.", Toast.LENGTH_LONG).show();
                KioskModeUtil.triggerLauncherChooser(getApplicationContext());
                finish();
                System.exit(0);
                return true;
            }
        });



        Preference onOffToggleButton = findPreference("pref_kiosk_mode");

        onOffToggleButton.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                boolean isActive = (Boolean)newValue;

                if (!isActive) {
                    // has been deactivated
                    Toast.makeText(getApplicationContext(), "Deactivated", Toast.LENGTH_LONG).show();
                    KioskModeUtil.removeStatusbarOverlay(getApplicationContext());
                    // triggerLauncherChooser();
                } else {
                    // has been activated
                    if (!KioskModeUtil.isMyLauncherDefault(getApplicationContext())) {
                        Toast.makeText(getApplicationContext(), "Activated, please set the Kiosk App as default home screen.", Toast.LENGTH_LONG).show();
                        KioskModeUtil.triggerLauncherChooser(getApplicationContext());
                    } else {
                        Toast.makeText(getApplicationContext(), "Activated", Toast.LENGTH_LONG).show();
                    }
                    // triggerLauncherChooser();

                }
                return true;
            }
        });

        Preference AllowedApps = findPreference("pref_AllowedApps");

        AllowedApps.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                Intent intent = new Intent(getApplicationContext(), AppChooserActivity.class);
                startActivity(intent);
                return true;
            }
        });

    }

}
